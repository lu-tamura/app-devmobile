package com.example.bbbapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class BBBAPP_2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bbbapp2)
        lateinit var button1: Button

        button1 = findViewById(R.id.botao_entrar)

        button1.setOnClickListener {
            IrParaTerceiraTela()


        }

    }


    private fun IrParaTerceiraTela(){
        val terceiraTela = Intent(this,BBBAPP_33::class.java)
        startActivity(terceiraTela)
    }
}