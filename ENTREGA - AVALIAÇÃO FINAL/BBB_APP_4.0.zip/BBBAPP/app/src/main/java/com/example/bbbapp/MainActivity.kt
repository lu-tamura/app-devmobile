package com.example.bbbapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lateinit var button1: Button
        lateinit var button2: Button


        button1 = findViewById(R.id.botao_entre)

        button2 = findViewById(R.id.botao_cadastro)

        button1.setOnClickListener {
            IrParaSegundaTela()

        }

        button2.setOnClickListener {
            IrParaSegundaTela()

        }

    }

    private fun IrParaSegundaTela(){
        val segundaTela = Intent(this,BBBAPP_2::class.java)
        startActivity(segundaTela)
    }


}