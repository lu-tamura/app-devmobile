package com.example.bbbapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.graphics.drawable.Drawable
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.style.ImageSpan
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat;

class BBBAPP_33 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bbbapp33)

        val button_compra: Button = findViewById(R.id.comprar)
        val botao_saida: Button = findViewById(R.id.saida)
        val botao_user: Button = findViewById(R.id.usuario)


        button_compra.setOnClickListener {
            val intent = Intent(this, BBBAPP_3::class.java)
            startActivity(intent)}
        botao_saida.setOnClickListener {
            val intent2 = Intent(this, MainActivity::class.java)
            startActivity(intent2)}
        botao_user.setOnClickListener {
            val intent3 = Intent(this, BBBAPP_2::class.java)
            startActivity(intent3)}



        val textView = findViewById<TextView>(R.id.textopcao1)
        val textView2 = findViewById<TextView>(R.id.textopcao2)
        val textView3 = findViewById<TextView>(R.id.textopcao3)
        val textView4 = findViewById<TextView>(R.id.textopcao4)
        val textView5 = findViewById<TextView>(R.id.textopcao5)

        // Carregando a imagem
        val drawable: Drawable? = ContextCompat.getDrawable(this, R.drawable.xbbb)
        val drawable2: Drawable? = ContextCompat.getDrawable(this, R.drawable.duplo)
        val drawable3: Drawable? = ContextCompat.getDrawable(this, R.drawable.especial)
        val drawable4: Drawable? = ContextCompat.getDrawable(this, R.drawable.bbkids)
        val drawable5: Drawable? = ContextCompat.getDrawable(this, R.drawable.combobbb)

        // Criando um SpannableStringBuilder
        val spannableStringBuilder = SpannableStringBuilder("@string/opcao1 ")
        val spannableStringBuilder2 = SpannableStringBuilder("@string/opcao2 ")
        val spannableStringBuilder3 = SpannableStringBuilder("@string/opcao3 ")
        val spannableStringBuilder4 = SpannableStringBuilder("@string/opcao4 ")
        val spannableStringBuilder5 = SpannableStringBuilder("@string/opcao5 ")

        //1
        // Adicionando a imagem ao SpannableStringBuilder
        if (drawable != null) {
            drawable.setBounds(0, 0, drawable.intrinsicWidth, drawable.intrinsicHeight)
            val imageSpan = ImageSpan(drawable)
            spannableStringBuilder.setSpan(imageSpan, spannableStringBuilder.length - 1, spannableStringBuilder.length, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        // Adicionando mais texto ao SpannableStringBuilder
        spannableStringBuilder.append("Texto final.")

        // Configurando o SpannableStringBuilder no TextView
        textView.text = spannableStringBuilder

        //2
        if (drawable2 != null) {
            drawable2.setBounds(0, 0, drawable2.intrinsicWidth, drawable2.intrinsicHeight)
            val imageSpan2 = ImageSpan(drawable2)
            spannableStringBuilder.setSpan(imageSpan2, spannableStringBuilder2.length - 1, spannableStringBuilder2.length, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        // Configurando o SpannableStringBuilder no TextView
        textView2.text = spannableStringBuilder2

        //3
        if (drawable3 != null) {
            drawable3.setBounds(0, 0, drawable3.intrinsicWidth, drawable3.intrinsicHeight)
            val imageSpan3 = ImageSpan(drawable3)
            spannableStringBuilder.setSpan(imageSpan3, spannableStringBuilder3.length - 1, spannableStringBuilder3.length, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        // Configurando o SpannableStringBuilder no TextView
        textView3.text = spannableStringBuilder3

        //4
        // Adicionando a imagem ao SpannableStringBuilder
        if (drawable4 != null) {
            drawable4.setBounds(0, 0, drawable4.intrinsicWidth, drawable4.intrinsicHeight)
            val imageSpan4 = ImageSpan(drawable4)
            spannableStringBuilder4.setSpan(imageSpan4, spannableStringBuilder4.length - 1, spannableStringBuilder4.length, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        // Configurando o SpannableStringBuilder no TextView
        textView4.text = spannableStringBuilder4

        //5
        // Adicionando a imagem ao SpannableStringBuilder
        if (drawable5 != null) {
            drawable5.setBounds(0, 0, drawable5.intrinsicWidth, drawable5.intrinsicHeight)
            val imageSpan5 = ImageSpan(drawable5)
            spannableStringBuilder5.setSpan(imageSpan5, spannableStringBuilder5.length - 1, spannableStringBuilder5.length, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        // Configurando o SpannableStringBuilder no TextView
        textView5.text = spannableStringBuilder5
    }
}



