package com.example.bbbapp


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import android.widget.RadioButton
import android.widget.RadioGroup
import android.view.View
import android.widget.Button

class BBBAPP_3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        var rGrupo: RadioGroup? = null
        lateinit var rBotao: RadioButton

        lateinit var button: Button
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bbbapp3)

        title = "AP1- RadioGroup"

        rGrupo = findViewById(R.id.rGrupo1)

        button = findViewById(R.id.bEnviar)

        button.setOnClickListener {

            val opcaoEscolhida: Int = rGrupo!!.checkedRadioButtonId

            rBotao = findViewById(opcaoEscolhida)

            Toast.makeText(baseContext, rBotao.text, Toast.LENGTH_SHORT).show()
        }
    }
}